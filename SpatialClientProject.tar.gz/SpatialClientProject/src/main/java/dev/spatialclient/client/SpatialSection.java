package dev.spatialclient.client;

public enum SpatialSection {
    HOME("Home", "Overview", 24.0F, 3.25, 0.35),
    VISUALS("Visuals", "Screen-only polish", 33.0F, 3.45, 0.30),
    HUD("HUD", "Useful client overlays", 8.0F, 3.05, 0.28),
    COSMETICS("Cosmetics", "Aura and player presentation", -28.0F, 3.55, 0.42),
    CAMERA("Camera", "Spatial view behavior", -12.0F, 2.85, 0.58),
    SETTINGS("Settings", "Client preferences", 18.0F, 3.15, 0.48);

    public final String title;
    public final String subtitle;
    public final float yawOffset;
    public final double distance;
    public final double heightOffset;

    SpatialSection(String title, String subtitle, float yawOffset, double distance, double heightOffset) {
        this.title = title;
        this.subtitle = subtitle;
        this.yawOffset = yawOffset;
        this.distance = distance;
        this.heightOffset = heightOffset;
    }
}
