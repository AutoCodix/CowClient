package dev.spatialclient.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.util.Mth;
import net.minecraftforge.client.event.RenderPlayerEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

public final class HeadTracking {
    private static float mouseXNorm;
    private static float mouseYNorm;
    private static boolean saved;
    private static float oldHead;
    private static float oldHeadO;
    private static float oldPitch;
    private static float oldPitchO;

    private HeadTracking() {
    }

    public static void updateMouse(double mouseX, double mouseY, int width, int height) {
        if (width <= 0 || height <= 0) return;
        mouseXNorm = Mth.clamp((float) ((mouseX / width) * 2.0 - 1.0), -1.0F, 1.0F);
        mouseYNorm = Mth.clamp((float) ((mouseY / height) * 2.0 - 1.0), -1.0F, 1.0F);
    }

    @SubscribeEvent(receiveCanceled = true)
    public static void onPlayerPre(RenderPlayerEvent.Pre event) {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer player = mc.player;
        if (player == null || event.getEntity() != player || !SpatialCamera.isMenuCameraActive()) return;
        if (!dev.spatialclient.config.SpatialConfig.get().headFollow) return;

        restore();
        saved = true;
        oldHead = player.yHeadRot;
        oldHeadO = player.yHeadRotO;
        oldPitch = player.getXRot();
        oldPitchO = player.xRotO;

        float head = player.yBodyRot - mouseXNorm * 34.0F;
        float pitch = Mth.clamp(mouseYNorm * 23.0F, -23.0F, 23.0F);
        player.yHeadRot = head;
        player.yHeadRotO = head;
        player.setXRot(pitch);
        player.xRotO = pitch;
    }

    @SubscribeEvent(receiveCanceled = true)
    public static void onPlayerPost(RenderPlayerEvent.Post event) {
        if (event.getEntity() == Minecraft.getInstance().player) restore();
    }

    @SubscribeEvent
    public static void onRenderEnd(TickEvent.RenderTickEvent event) {
        if (event.phase == TickEvent.Phase.END) restore();
    }

    private static void restore() {
        if (!saved) return;
        LocalPlayer player = Minecraft.getInstance().player;
        if (player != null) {
            player.yHeadRot = oldHead;
            player.yHeadRotO = oldHeadO;
            player.setXRot(oldPitch);
            player.xRotO = oldPitchO;
        }
        saved = false;
    }
}
