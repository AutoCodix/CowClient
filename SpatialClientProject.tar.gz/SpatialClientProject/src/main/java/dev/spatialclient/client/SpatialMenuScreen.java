package dev.spatialclient.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import dev.spatialclient.config.SpatialConfig;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

public final class SpatialMenuScreen extends Screen {
    private static final int PANEL_W = 390;
    private static final int PANEL_H = 286;
    private static final int SIDEBAR_W = 100;

    private SpatialSection section = SpatialSection.HOME;
    private final List<Row> rows = new ArrayList<>();
    private int panelX;
    private int panelY;

    public SpatialMenuScreen() {
        super(Component.literal("Spatial Client"));
    }

    @Override
    protected void init() {
        super.init();
        SpatialCamera.setSection(section);
        rebuildRows();
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        SpatialCamera.setMouse(mouseX, mouseY, width, height);
        HeadTracking.updateMouse(mouseX, mouseY, width, height);

        panelX = Math.max(14, width / 2 - PANEL_W / 2 - 115);
        panelY = Math.max(14, height / 2 - PANEL_H / 2);

        int accent = 0xFF000000 | SpatialConfig.get().accentRgb;
        g.fill(panelX, panelY, panelX + PANEL_W, panelY + PANEL_H, 0xE80B0D12);
        g.fill(panelX, panelY, panelX + 2, panelY + PANEL_H, accent);
        g.fill(panelX + SIDEBAR_W, panelY, panelX + SIDEBAR_W + 1, panelY + PANEL_H, 0xFF222630);

        g.drawString(font, "SPATIAL", panelX + 14, panelY + 13, 0xFFF4F5F8, false);
        g.drawString(font, "visual client", panelX + 14, panelY + 26, 0xFF747B89, false);

        int sy = panelY + 52;
        for (SpatialSection s : SpatialSection.values()) {
            boolean selected = s == section;
            boolean hover = mouseX >= panelX + 8 && mouseX <= panelX + SIDEBAR_W - 8 && mouseY >= sy && mouseY < sy + 25;
            if (selected || hover) {
                g.fill(panelX + 8, sy, panelX + SIDEBAR_W - 8, sy + 24, selected ? 0xFF171B24 : 0xA514171D);
            }
            if (selected) g.fill(panelX + 8, sy, panelX + 10, sy + 24, accent);
            g.drawString(font, s.title, panelX + 16, sy + 8, selected ? 0xFFF1F3F7 : 0xFF9EA5B1, false);
            sy += 29;
        }

        int contentX = panelX + SIDEBAR_W + 16;
        g.drawString(font, section.title, contentX, panelY + 16, 0xFFF4F5F8, false);
        g.drawString(font, section.subtitle, contentX, panelY + 29, 0xFF757D8C, false);
        g.fill(contentX, panelY + 44, panelX + PANEL_W - 14, panelY + 45, 0xFF20242D);

        if (section == SpatialSection.HOME) {
            drawHome(g, contentX, panelY + 59);
        } else {
            drawRows(g, mouseX, mouseY, contentX, panelY + 58);
        }

        g.drawString(font, "RSHIFT / ESC  close", contentX, panelY + PANEL_H - 18, 0xFF5F6672, false);
        super.render(g, mouseX, mouseY, partialTick);
    }

    private void drawHome(GuiGraphics g, int x, int y) {
        int accent = 0xFF000000 | SpatialConfig.get().accentRgb;
        drawInfo(g, x, y, "Spatial camera", "Front-facing view with collision + smooth transitions", accent);
        drawInfo(g, x, y + 48, "Player presentation", "Your real skin stays in-world; head follows the cursor", accent);
        drawInfo(g, x, y + 96, "Client-only visuals", "HUD, crosshair and aura never change server gameplay", accent);
        drawInfo(g, x, y + 144, "Compatibility first", "No mixins, no packet hooks, no shader replacement", accent);
    }

    private void drawInfo(GuiGraphics g, int x, int y, String title, String desc, int accent) {
        int right = panelX + PANEL_W - 16;
        g.fill(x, y, right, y + 39, 0xB012151B);
        g.fill(x, y, x + 2, y + 39, accent);
        g.drawString(font, title, x + 9, y + 7, 0xFFE8EAF0, false);
        g.drawString(font, desc, x + 9, y + 21, 0xFF7F8795, false);
    }

    private void drawRows(GuiGraphics g, int mouseX, int mouseY, int x, int y) {
        for (int i = 0; i < rows.size(); i++) {
            Row row = rows.get(i);
            int ry = y + i * 35;
            int right = panelX + PANEL_W - 16;
            boolean hover = mouseX >= x && mouseX <= right && mouseY >= ry && mouseY < ry + 29;
            g.fill(x, ry, right, ry + 29, hover ? 0xE0181C24 : 0xC012151B);
            g.drawString(font, row.name, x + 9, ry + 6, 0xFFE8EAF0, false);
            g.drawString(font, row.description, x + 9, ry + 17, 0xFF6F7785, false);
            String value = row.value.get();
            int vw = font.width(value);
            int color = row.active.get() ? (0xFF000000 | SpatialConfig.get().accentRgb) : 0xFF8B929E;
            g.drawString(font, value, right - vw - 9, ry + 10, color, false);
        }
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button != 0) return super.mouseClicked(mouseX, mouseY, button);

        int sy = panelY + 52;
        for (SpatialSection s : SpatialSection.values()) {
            if (mouseX >= panelX + 8 && mouseX <= panelX + SIDEBAR_W - 8 && mouseY >= sy && mouseY < sy + 25) {
                section = s;
                SpatialCamera.setSection(s);
                rebuildRows();
                return true;
            }
            sy += 29;
        }

        if (section != SpatialSection.HOME) {
            int x = panelX + SIDEBAR_W + 16;
            int y = panelY + 58;
            int right = panelX + PANEL_W - 16;
            for (int i = 0; i < rows.size(); i++) {
                int ry = y + i * 35;
                if (mouseX >= x && mouseX <= right && mouseY >= ry && mouseY < ry + 29) {
                    rows.get(i).action.run();
                    SpatialConfig.get().save();
                    rebuildRows();
                    return true;
                }
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == GLFW.GLFW_KEY_RIGHT_SHIFT || keyCode == GLFW.GLFW_KEY_ESCAPE) {
            onClose();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public void onClose() {
        SpatialCamera.beginClose();
        if (minecraft != null) minecraft.setScreen(null);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    private void rebuildRows() {
        rows.clear();
        SpatialConfig c = SpatialConfig.get();
        switch (section) {
            case VISUALS -> {
                rows.add(toggle("Custom crosshair", "Replaces only the local vanilla crosshair", () -> c.customCrosshair, v -> c.customCrosshair = v));
                rows.add(cycle("Crosshair style", "Cross, dot or brackets", () -> c.crosshairStyle.name(), () -> c.crosshairStyle = next(c.crosshairStyle, SpatialConfig.CrosshairStyle.values())));
            }
            case HUD -> {
                rows.add(toggle("FPS", "Compact frame-rate widget", () -> c.fpsHud, v -> c.fpsHud = v));
                rows.add(toggle("Ping", "Current connection latency", () -> c.pingHud, v -> c.pingHud = v));
                rows.add(toggle("Coordinates", "Compact XYZ readout", () -> c.coordinatesHud, v -> c.coordinatesHud = v));
                rows.add(toggle("Keystrokes", "WASD and mouse input display", () -> c.keystrokesHud, v -> c.keystrokesHud = v));
                rows.add(toggle("Armor", "Armor icons above the hotbar", () -> c.armorHud, v -> c.armorHud = v));
                rows.add(toggle("Effects", "Clean active-effect list", () -> c.effectsHud, v -> c.effectsHud = v));
            }
            case COSMETICS -> {
                rows.add(toggle("Aura", "Local-only aura in F5 and this menu", () -> c.aura, v -> c.aura = v));
                rows.add(cycle("Aura style", "Orbit, helix or halo", () -> c.auraStyle.name(), () -> c.auraStyle = next(c.auraStyle, SpatialConfig.AuraStyle.values())));
                rows.add(cycle("Aura intensity", "Amount of geometry around your player", () -> Integer.toString(c.auraIntensity), () -> c.auraIntensity = c.auraIntensity >= 3 ? 1 : c.auraIntensity + 1));
            }
            case CAMERA -> {
                rows.add(toggle("Head follows cursor", "Render-only head tracking; server rotation stays untouched", () -> c.headFollow, v -> c.headFollow = v));
                rows.add(toggle("Cursor parallax", "Small camera response to cursor position", () -> c.menuParallax, v -> c.menuParallax = v));
                rows.add(toggle("Camera collision", "Stops the spatial camera entering blocks", () -> c.cameraCollision, v -> c.cameraCollision = v));
                rows.add(cycle("Camera smoothing", "Transition speed between spatial windows", () -> smoothingLabel(c.cameraSmoothness), () -> c.cameraSmoothness = nextSmoothness(c.cameraSmoothness)));
            }
            case SETTINGS -> {
                rows.add(cycle("Accent", "Cycles through restrained client accents", () -> accentName(c.accentRgb), () -> c.accentRgb = nextAccent(c.accentRgb)));
                rows.add(cycle("Reset visuals", "Click to restore the default visual configuration", () -> "RESET", SpatialMenuScreen::resetVisuals));
            }
            default -> {
            }
        }
    }

    private static void resetVisuals() {
        SpatialConfig c = SpatialConfig.get();
        c.fpsHud = true;
        c.pingHud = true;
        c.coordinatesHud = true;
        c.keystrokesHud = true;
        c.armorHud = true;
        c.effectsHud = true;
        c.customCrosshair = true;
        c.aura = true;
        c.headFollow = true;
        c.menuParallax = true;
        c.cameraCollision = true;
        c.auraStyle = SpatialConfig.AuraStyle.ORBIT;
        c.crosshairStyle = SpatialConfig.CrosshairStyle.CROSS;
        c.auraIntensity = 2;
        c.cameraSmoothness = 0.18F;
        c.accentRgb = 0x7700FF;
    }

    private static float nextSmoothness(float current) {
        if (current < 0.14F) return 0.18F;
        if (current < 0.24F) return 0.30F;
        return 0.10F;
    }

    private static String smoothingLabel(float v) {
        if (v < 0.14F) return "SOFT";
        if (v < 0.24F) return "BALANCED";
        return "SNAPPY";
    }

    private static int nextAccent(int rgb) {
        if (rgb == 0x7700FF) return 0x00A8FF;
        if (rgb == 0x00A8FF) return 0x00D6A3;
        if (rgb == 0x00D6A3) return 0xFF4D8D;
        return 0x7700FF;
    }

    private static String accentName(int rgb) {
        return switch (rgb) {
            case 0x7700FF -> "VIOLET";
            case 0x00A8FF -> "OCEAN";
            case 0x00D6A3 -> "MINT";
            case 0xFF4D8D -> "ROSE";
            default -> "CUSTOM";
        };
    }

    private static <E extends Enum<E>> E next(E value, E[] all) {
        int index = (value.ordinal() + 1) % all.length;
        return all[index];
    }

    private static Row toggle(String name, String desc, BoolGet get, BoolSet set) {
        return new Row(name, desc, () -> get.get() ? "ON" : "OFF", get, () -> set.set(!get.get()));
    }

    private static Row cycle(String name, String desc, TextGet value, Runnable action) {
        return new Row(name, desc, value, () -> true, action);
    }

    private interface BoolGet { boolean get(); }
    private interface BoolSet { void set(boolean v); }
    private interface TextGet { String get(); }
    private record Row(String name, String description, TextGet value, BoolGet active, Runnable action) {}
}
