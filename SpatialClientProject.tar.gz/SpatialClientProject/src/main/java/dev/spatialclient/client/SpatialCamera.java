package dev.spatialclient.client;

import net.minecraft.client.CameraType;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.player.RemotePlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

public final class SpatialCamera {
    private static RemotePlayer cameraEntity;
    private static Entity previousCameraEntity;
    private static CameraType previousCameraType;
    private static Vec3 currentEye;
    private static float currentYaw;
    private static float currentPitch;
    private static boolean active;
    private static boolean closing;
    private static long lastNanos;
    private static SpatialSection section = SpatialSection.HOME;
    private static float mouseXNorm;
    private static float mouseYNorm;

    private SpatialCamera() {
    }

    public static void open() {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer player = mc.player;
        if (player == null || mc.level == null || active) return;

        previousCameraEntity = mc.getCameraEntity();
        previousCameraType = mc.options.getCameraType();
        cameraEntity = new RemotePlayer(mc.level, player.getGameProfile());
        currentEye = player.getEyePosition(1.0F);
        currentYaw = player.getYRot() + 180.0F;
        currentPitch = 0.0F;
        syncCameraEntity();

        active = true;
        closing = false;
        lastNanos = System.nanoTime();
        mc.options.setCameraType(CameraType.FIRST_PERSON);
        mc.setCameraEntity(cameraEntity);
    }

    public static void beginClose() {
        if (!active) return;
        closing = true;
        lastNanos = System.nanoTime();
    }

    public static void forceRestore() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player != null) {
            mc.setCameraEntity(previousCameraEntity != null ? previousCameraEntity : mc.player);
        }
        if (previousCameraType != null) mc.options.setCameraType(previousCameraType);
        active = false;
        closing = false;
        cameraEntity = null;
        previousCameraEntity = null;
        previousCameraType = null;
        currentEye = null;
    }

    public static boolean isMenuCameraActive() {
        return active && !closing;
    }

    public static boolean isAnySpatialCameraActive() {
        return active;
    }

    public static void setSection(SpatialSection newSection) {
        if (newSection != null) section = newSection;
    }

    public static void setMouse(double mouseX, double mouseY, int width, int height) {
        if (width <= 0 || height <= 0) return;
        mouseXNorm = Mth.clamp((float) ((mouseX / width) * 2.0 - 1.0), -1.0F, 1.0F);
        mouseYNorm = Mth.clamp((float) ((mouseY / height) * 2.0 - 1.0), -1.0F, 1.0F);
    }

    @SubscribeEvent
    public static void onRenderTick(TickEvent.RenderTickEvent event) {
        if (event.phase != TickEvent.Phase.START || !active) return;
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer player = mc.player;
        if (player == null || mc.level == null || cameraEntity == null) {
            forceRestore();
            return;
        }

        long now = System.nanoTime();
        float dt = lastNanos == 0L ? 1.0F / 60.0F : Math.min(0.05F, (now - lastNanos) / 1_000_000_000.0F);
        lastNanos = now;

        Vec3 targetEye;
        float targetYaw;
        float targetPitch;

        if (closing) {
            targetEye = player.getEyePosition(event.renderTickTime);
            targetYaw = player.getYRot();
            targetPitch = player.getXRot();
        } else {
            Vec3 focus = player.position().add(0.0, 1.35, 0.0);
            float baseYaw = player.yBodyRot + 180.0F + section.yawOffset;
            float parallaxYaw = dev.spatialclient.config.SpatialConfig.get().menuParallax ? mouseXNorm * 4.5F : 0.0F;
            double yawRad = Math.toRadians(baseYaw + parallaxYaw);
            double side = Math.sin(yawRad) * section.distance;
            double forward = -Math.cos(yawRad) * section.distance;
            double py = section.heightOffset + (dev.spatialclient.config.SpatialConfig.get().menuParallax ? -mouseYNorm * 0.10 : 0.0);
            targetEye = focus.add(side, py, forward);

            if (dev.spatialclient.config.SpatialConfig.get().cameraCollision) {
                BlockHitResult hit = mc.level.clip(new ClipContext(focus, targetEye, ClipContext.Block.VISUAL, ClipContext.Fluid.NONE, player));
                if (hit.getType() != HitResult.Type.MISS) {
                    Vec3 hitPos = hit.getLocation();
                    Vec3 towardFocus = focus.subtract(hitPos);
                    if (towardFocus.lengthSqr() > 1.0E-6) hitPos = hitPos.add(towardFocus.normalize().scale(0.14));
                    targetEye = hitPos;
                }
            }

            float[] look = lookAt(targetEye, focus.add(0.0, 0.15, 0.0));
            targetYaw = look[0];
            targetPitch = look[1];
        }

        float smoothness = dev.spatialclient.config.SpatialConfig.get().cameraSmoothness;
        float rate = closing ? 18.0F : (7.0F + smoothness * 45.0F);
        float a = 1.0F - (float) Math.exp(-rate * dt);
        if (currentEye == null) currentEye = targetEye;
        currentEye = currentEye.lerp(targetEye, a);
        currentYaw = rotLerp(currentYaw, targetYaw, a);
        currentPitch = Mth.lerp(a, currentPitch, targetPitch);
        syncCameraEntity();

        if (closing) {
            double posError = currentEye.distanceTo(targetEye);
            float yawError = Math.abs(Mth.wrapDegrees(currentYaw - targetYaw));
            if (posError < 0.035 && yawError < 2.0F) forceRestore();
        }
    }

    private static void syncCameraEntity() {
        if (cameraEntity == null || currentEye == null) return;
        double feetY = currentEye.y - cameraEntity.getEyeHeight();
        cameraEntity.setPos(currentEye.x, feetY, currentEye.z);
        cameraEntity.setYRot(currentYaw);
        cameraEntity.setXRot(currentPitch);
        cameraEntity.yRotO = currentYaw;
        cameraEntity.xRotO = currentPitch;
    }

    static float[] lookAt(Vec3 from, Vec3 to) {
        Vec3 d = to.subtract(from);
        double horizontal = Math.sqrt(d.x * d.x + d.z * d.z);
        float yaw = (float) (Math.toDegrees(Math.atan2(d.z, d.x)) - 90.0);
        float pitch = (float) -Math.toDegrees(Math.atan2(d.y, horizontal));
        return new float[]{yaw, pitch};
    }

    static float rotLerp(float from, float to, float alpha) {
        return from + Mth.wrapDegrees(to - from) * alpha;
    }
}
