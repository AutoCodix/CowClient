package dev.spatialclient.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import dev.spatialclient.config.SpatialConfig;

public final class AuraRenderer {
    private AuraRenderer() {
    }

    @SubscribeEvent
    public static void onRenderLevel(RenderLevelStageEvent event) {
        if (event.getStage() != RenderLevelStageEvent.Stage.AFTER_ENTITIES) return;
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer player = mc.player;
        SpatialConfig cfg = SpatialConfig.get();
        if (player == null || !cfg.aura || mc.options.hideGui) return;

        boolean thirdPerson = !mc.options.getCameraType().isFirstPerson();
        if (!thirdPerson && !SpatialCamera.isAnySpatialCameraActive()) return;

        Vec3 cam = event.getCamera().getPosition();
        double px = player.xOld + (player.getX() - player.xOld) * event.getPartialTick();
        double py = player.yOld + (player.getY() - player.yOld) * event.getPartialTick();
        double pz = player.zOld + (player.getZ() - player.zOld) * event.getPartialTick();

        PoseStack stack = event.getPoseStack();
        stack.pushPose();
        stack.translate(px - cam.x, py - cam.y, pz - cam.z);

        MultiBufferSource.BufferSource buffers = mc.renderBuffers().bufferSource();
        VertexConsumer vc = buffers.getBuffer(RenderType.lines());
        int rgb = cfg.accentRgb;
        int r = (rgb >> 16) & 255;
        int g = (rgb >> 8) & 255;
        int b = rgb & 255;
        float time = (player.tickCount + event.getPartialTick()) * 0.055F;

        switch (cfg.auraStyle) {
            case ORBIT -> drawOrbit(stack, vc, r, g, b, time, cfg.auraIntensity);
            case HELIX -> drawHelix(stack, vc, r, g, b, time, cfg.auraIntensity);
            case HALO -> drawHalo(stack, vc, r, g, b, time, cfg.auraIntensity);
        }

        buffers.endBatch(RenderType.lines());
        stack.popPose();
    }

    private static void drawOrbit(PoseStack stack, VertexConsumer vc, int r, int g, int b, float time, int intensity) {
        int rings = intensity + 1;
        for (int i = 0; i < rings; i++) {
            double y = 0.10 + i * (1.60 / Math.max(1, rings - 1));
            double radius = 0.48 + 0.06 * Math.sin(time * 2.0 + i);
            drawRing(stack, vc, r, g, b, 185, y, radius, time * (i % 2 == 0 ? 1.0 : -1.0));
        }
    }

    private static void drawHelix(PoseStack stack, VertexConsumer vc, int r, int g, int b, float time, int intensity) {
        int turns = 2 + intensity;
        int segments = 72 + intensity * 24;
        PoseStack.Pose pose = stack.last();
        for (int i = 0; i < segments; i++) {
            double t0 = (double) i / segments;
            double t1 = (double) (i + 1) / segments;
            double a0 = t0 * Math.PI * 2.0 * turns + time * 2.0;
            double a1 = t1 * Math.PI * 2.0 * turns + time * 2.0;
            double rad = 0.50;
            double y0 = 0.05 + t0 * 1.85;
            double y1 = 0.05 + t1 * 1.85;
            line(pose, vc, r, g, b, 190,
                    Math.cos(a0) * rad, y0, Math.sin(a0) * rad,
                    Math.cos(a1) * rad, y1, Math.sin(a1) * rad);
        }
    }

    private static void drawHalo(PoseStack stack, VertexConsumer vc, int r, int g, int b, float time, int intensity) {
        drawRing(stack, vc, r, g, b, 210, 2.05 + Math.sin(time * 2.0) * 0.035, 0.44, time);
        if (intensity >= 2) drawRing(stack, vc, r, g, b, 150, 0.06, 0.60, -time * 0.65F);
        if (intensity >= 3) drawRing(stack, vc, r, g, b, 125, 1.05, 0.56, time * 0.8F);
    }

    private static void drawRing(PoseStack stack, VertexConsumer vc, int r, int g, int b, int a,
                                 double y, double radius, float phase) {
        PoseStack.Pose pose = stack.last();
        int segments = 64;
        for (int i = 0; i < segments; i++) {
            double a0 = Math.PI * 2.0 * i / segments + phase;
            double a1 = Math.PI * 2.0 * (i + 1) / segments + phase;
            line(pose, vc, r, g, b, a,
                    Math.cos(a0) * radius, y, Math.sin(a0) * radius,
                    Math.cos(a1) * radius, y, Math.sin(a1) * radius);
        }
    }

    private static void line(PoseStack.Pose pose, VertexConsumer vc, int r, int g, int b, int a,
                             double x0, double y0, double z0, double x1, double y1, double z1) {
        float dx = (float) (x1 - x0);
        float dy = (float) (y1 - y0);
        float dz = (float) (z1 - z0);
        float len = (float) Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (len < 1.0E-5F) len = 1.0F;
        dx /= len;
        dy /= len;
        dz /= len;
        vc.vertex(pose.pose(), (float) x0, (float) y0, (float) z0).color(r, g, b, a).normal(pose.normal(), dx, dy, dz).endVertex();
        vc.vertex(pose.pose(), (float) x1, (float) y1, (float) z1).color(r, g, b, a).normal(pose.normal(), dx, dy, dz).endVertex();
    }
}
