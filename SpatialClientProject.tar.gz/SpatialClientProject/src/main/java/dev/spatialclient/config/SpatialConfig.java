package dev.spatialclient.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.minecraftforge.fml.loading.FMLPaths;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;

public final class SpatialConfig {
    public enum AuraStyle { ORBIT, HELIX, HALO }
    public enum CrosshairStyle { CROSS, DOT, BRACKETS }

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = FMLPaths.CONFIGDIR.get().resolve("spatialclient.json");
    private static SpatialConfig instance;

    public boolean fpsHud = true;
    public boolean pingHud = true;
    public boolean coordinatesHud = true;
    public boolean keystrokesHud = true;
    public boolean armorHud = true;
    public boolean effectsHud = true;
    public boolean customCrosshair = true;
    public boolean aura = true;
    public boolean headFollow = true;
    public boolean menuParallax = true;
    public boolean cameraCollision = true;
    public AuraStyle auraStyle = AuraStyle.ORBIT;
    public CrosshairStyle crosshairStyle = CrosshairStyle.CROSS;
    public int accentRgb = 0x7700FF;
    public int auraIntensity = 2;
    public float cameraSmoothness = 0.18F;

    private SpatialConfig() {
    }

    public static SpatialConfig get() {
        if (instance == null) load();
        return instance;
    }

    public static void load() {
        if (Files.isRegularFile(FILE)) {
            try (Reader reader = Files.newBufferedReader(FILE)) {
                SpatialConfig read = GSON.fromJson(reader, SpatialConfig.class);
                instance = read == null ? new SpatialConfig() : read;
            } catch (Exception ignored) {
                instance = new SpatialConfig();
            }
        } else {
            instance = new SpatialConfig();
        }
        instance.sanitize();
    }

    public void save() {
        sanitize();
        try {
            Files.createDirectories(FILE.getParent());
            try (Writer writer = Files.newBufferedWriter(FILE)) {
                GSON.toJson(this, writer);
            }
        } catch (IOException ignored) {
        }
    }

    private void sanitize() {
        auraIntensity = Math.max(1, Math.min(3, auraIntensity));
        cameraSmoothness = Math.max(0.08F, Math.min(0.35F, cameraSmoothness));
        accentRgb &= 0xFFFFFF;
        if (auraStyle == null) auraStyle = AuraStyle.ORBIT;
        if (crosshairStyle == null) crosshairStyle = CrosshairStyle.CROSS;
    }
}
