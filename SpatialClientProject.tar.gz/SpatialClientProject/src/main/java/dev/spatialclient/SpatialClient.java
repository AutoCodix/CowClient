package dev.spatialclient;

import net.minecraftforge.fml.common.Mod;

@Mod(SpatialClient.MOD_ID)
public final class SpatialClient {
    public static final String MOD_ID = "spatialclient";

    public SpatialClient() {
    }
}
