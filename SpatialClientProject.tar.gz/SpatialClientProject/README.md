# Spatial Client — Forge 1.20.1

Client-side visual client for Minecraft Forge 1.20.1.

## Included
- Right Shift spatial menu with smooth front-facing camera transitions.
- Camera collision and cursor parallax.
- Real in-world skin presentation while the menu is open.
- Render-only head tracking toward the cursor; real player rotation is restored after each render pass.
- Three client-only aura styles visible only when the player model is visible (F5/spatial camera).
- FPS, ping, coordinates, keystrokes, armor, and potion/effect HUD widgets.
- Custom crosshair with three styles.
- Persistent JSON config.
- No combat, movement, exploit, X-ray, ESP, packet, remote-script, or server-side features.
- No mixins and no shader replacement, to minimize mod conflicts.

## Build
Requires JDK 17 and Forge 1.20.1 dependencies. Build with Gradle 8.8 / ForgeGradle 6:

`gradle clean build`

The reobfuscated mod JAR is produced in `build/libs/`.
