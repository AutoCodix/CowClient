@echo off
setlocal
where java >nul 2>nul || (echo Java 17 is required.& exit /b 1)
where gradle >nul 2>nul || (echo Gradle 8.x is required if gradlew is not present.& exit /b 1)
gradle clean build --no-daemon
if errorlevel 1 exit /b %errorlevel%
echo.
echo Built JARs:
dir /b build\libs\*.jar
